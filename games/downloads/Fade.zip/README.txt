Hey! Thanks for this game I (Ziixx) made!

This is freeware, so share it if you want.

However, do not host this and/or pass it off as your own on the internet or anywhere else,
just link it to my website: https://ziixx.net/
if you distribute or share the file anywhere else this readme file must be attached.

If you enjoy, please do share it with your friends, and if you have any comments or just want to say hi
send me a note, my contacts are on my website!

Until next time, 
Ziixx.