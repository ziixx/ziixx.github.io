===========================Credits===========================

Nanobodies Poster and Models:
Bah et al. "Na'Nobody' Likes Covid-19!: The Role of Nanobodies in Fighting COVID-19." Edited by Jim Lane, https://ziixx.net/projects/MaPS2022.html, 2022.

Meditopia Poster and Models:
Coler et al. "Meditopia: Meditope-Enabled Bonds and their Affinity with Cetuximab." Edited by Jim Lane, https://ziixx.net/projects/MaPS2022.html, 2022.

Rheumatoid Arthritis Poster and Models:
Chen et al. "On the Flame: The Fab Fragment of Rheumatoid Arthritis." Edited by Jim Lane, https://ziixx.net/projects/MaPS2022.html, 2022.

Influenza/Monoclonal Antibodies Poster and Models:
Cegielski et al. "Engineering a Better FLUture with Monoclonal Antibodies." Edited by Jim Lane, https://ziixx.net/projects/MaPS2022.html, 2022.

7OAN Protein:
Naismith J.H. and Weckener M. “RCSB PDB - 7OAN: Nanobody C5 Bound to Spike.” (2021) The Protein Data Bank. doi: 10.2210/pdb7OAN/pdb. Accessed 1 Mar. 2022.

===========================In order to view any model===========================

Download Jmol from http://jmol.sourceforge.net/download/

===========================In order to view the model NanobodyModel 1 & 2===========================


Jmol is very weird when you move files accross computers.
When you write a state, the only way I have found to save pdb files across instances, that state doesn't create a unique file.
Instead, it creates a pointer to the old file (in this case 7OAN_nano...pdb) and then attaches modifiers to it. 
This means that when you want to send someone the PDB file, you have to send the original file too. 
Not only do you have to send both of them, but you also have to format the filepath for each computer.
For example, on my computer the pointer points to "/*file*/"file:/C:/Users/ltkri/Desktop/Files/Files/MAPS/Models/7oan_spikeDownAndNanobody.pdb" currently.
What needs to happen is you need to go to this line in the "3DModel.txt" or "3DmodelFig2.txt" (it should start with "load") and edit the filepath to match your computer's filepath to 7OAN.
Then, convert the file into a .pdb format. 